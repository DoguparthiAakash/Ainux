#include "devtab-Inferno.c"
