var searchData=
[
  ['about_20the_20extended_20c_20library_3a_20libxc',['About The Extended C Library: libxc',['../index.html',1,'']]]
];
